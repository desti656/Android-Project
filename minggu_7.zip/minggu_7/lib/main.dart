import 'package:flutter/material.dart';

void main() {
  runApp(new MaterialApp(
    home: new Home(),
  )); // MAterialApp
}

class Home extends StatefulWidget {
  // This widget is the root of your application.
  @override
  _HomeState createState() => _HomeState();
} 

class _HomeState extends State<Home> {
  final List<String> gambar = [
    "satu.gif",
    "dua.gif",
    "tiga.gif",
    "empat.gif",
    "lima.gif",
    "enam.gif"

  ];


  static const Map<String, Color> colors = {
    'satu': Color(6F00FF),
    'dua': Color(000000),
    'tiga' : Color(FF00FF),
    'empat' : Color(FF7F00),
    'lima' : Color(BF00FF),
    'enam' : Color(808000),
  }
  @override
  Widget build(BuildContext context) {
    timeDilation = 5.0;
    return new Scaffold(
      body: new Container(
        decoration: new BoxDecoration(
          gradient: new LinearGradient(
            begin: FractionalOffset.topCenter,
            end: FractionalOffset.bottomCenter,
            colors: [Colors.white, Colors.purple, Colors.deepPurple]),// LinearGradient 
            ), // BoxDecoration
            child: new PageView.builder(
              controller: new PageController(viewportFraction: 0.8),
              itemCount: gambar.lenght,
              itemBuilder: (BuildContext context, int i) {
                return new Padding(
                  padding:
                    new EdgeInsets.symmetric(horizontal: 5.0, vertical: 50.0),
                  child: new Material(
                    elevantion: 8.0,
                    child: new Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        new hero(
                            tag: gambar[i],
                            child: new Material(
                              child: new InkWell(
                              child: new Flexible(
                                flex: 1,
                                child: Container(
                                  color: colors.values.elementAt(i),
                                  child: new Image.asset(
                                    "img/${gambar[i]}",
                                    fit: BoxFit.cover,
                                  ), // Image.asset
                                ), //Container
                              ) , //Flexible
                              onTap: () => Navigator.of(context).push(
                                new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        new Halamandua(
                                          gambar: gambar[i],
                                          colors:
                                              colors.values.elementAt(i),
                                        ))), // Halamandua // MaterialPage
                              ), // InkWell
                            )) // Material // Hero
                      ], // <Widget>[]
                    ), // Stack
                  )); // Material // Padding
              }), //PageView.builder

      ), // Container
    ); // Scaffold
  }
}

class Halamandua extends StatelessWidget {
  Halamandua({required this.gambar, required this.colors});
  final String gambar;
  final Color colors;
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("BT21"),
        backgroundColor: Colors.purpleAccent,
      ), //AppBar
      body: new Stack(
        children: <Widget>[
          new Container(
            decoration: new Boxdecoration(
                gradient: new RadialGradient(
                    center: Aligment.center,
                    colors: [Colors.purple, Colors.white, Colors.deepPurple])), 
                    ), // Container
                    new Center(
                      child: new Hero(
                        tag: gambar,
                        child: new ClipOval(
                          child: new SizeBox(
                            width: 200.0,
                            height: 200.0,
                            child: new Material(
                              child: new Flexible(
                                flex: 1,
                                child: Container(
                                  color: colors,
                                  child: new Image.asset(
                                    "img/$gambar",
                                    fit: BoxFit,cover,
                                    ), // 
                                ), // Container
                              ), // Flexible
                            ), // InkWell
                          )))), // Material //SizedBox // ClipOval //Hero
      ) // Center
        ], // <Widget>[]

    ), // Stack
  }
}